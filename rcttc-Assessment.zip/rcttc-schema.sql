use master;
go
drop database if exists RCTTC;
GO
create database RCTTC;
GO
use RCTTC;
GO

create table Customer(
    CustomerId int primary key identity(1,1),
    FirstName varchar(50) null,
    LastName varchar(50) null,
    CustomerEmail varchar(50) null,
    CustomerPhone varchar(50) null,
    CustomerAddress varchar(50) null
)

create table Performance(
    PerformanceId int primary key identity (1,1),
    Show VARCHAR(50) not null,
    StartDate Date not null,
    

)

create Table CustomerPerformance(
    CustomerId int not null,
    PerformanceId int not null,
    Constraint pk_CustomerPerformance
    primary key(CustomerId, PerformanceId),
     Constraint fk_CustomerPerformance_CustomerId
        FOREIGN key (CustomerId)
         REFERENCES Customer(CustomerId),
    Constraint fk_CustomerPerformance_PerformanceId
         FOREIGN key (PerformanceId)
        REFERENCES Performance(PerformanceId)
    
)
-- change constraint below
--alter table CustomerPerformance
--   Add CONSTRAINT fk_CustomerPerformance_Ticket_TicketId FOREIGN KEY (TicketId) REFERENCES Ticket(TicketId)

create table Ticket(
    TicketId int primary key identity (1,1),
    PerformanceId int not null,
    Seat VARCHAR (50) not null,
    TicketPrice decimal(18,2) not null,
    CustomerId int not null,
    Constraint fk_Ticket_CustomerId
    FOREIGN Key (CustomerId)
    References Customer(CustomerId)
)

create table Theater(
    TheaterId int primary key IDENTITY(1,1),
    TheaterName VARCHAR(50) not null,
    TheaterAddress VARCHAR(50) not null,
    TheaterPhone VARCHAR(50) not null,
    TheaterEmail VARCHAR(50) not null,
    --CONSTRAINT fk_Theater_PerformanceId
    --FOREIGN KEY (PerformanceId)
    --REFERENCES 

)
create table PerformanceTheater(
    PerformanceId int not null,
    TheaterId int not null,
)
