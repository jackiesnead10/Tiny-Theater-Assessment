use RCTTC
--drop table Customer
--Customer Data insert
--drop Table Ticket

Begin TRAN
Insert into Customer (FirstName, LastName, CustomerEmail, CustomerPhone, CustomerAddress)
SELECT DISTINCT
    [customer_first],
    [customer_last],
    [customer_email],
    [customer_phone],
    [customer_address]
from [RCTTC].[dbo].[rcttc-data];

select * 
from Customer
commit TRAN

--Performance Data Insert
Begin TRAN
insert into Performance (Show, StartDate)
Select distinct
    [show],
    [date]
from [RCTTC].[dbo].[rcttc-data];

Select *
from Performance 
commit TRAN
--Show data insert
-- check null in statement below

--Ticket Data insert
--two inner joins for ids

Begin TRAN
insert into Ticket(PerformanceId, Seat, TicketPrice, CustomerId)
select 
    p.PerformanceId,
   r.[seat],
   r.[ticket_price],
    c.CustomerId
from [RCTTC].[dbo].[rcttc-data] r
inner join Performance p on p.Show = r.show
and r.date = p.StartDate
inner join Customer c on r.customer_email = c.CustomerEmail


Select * 
from Ticket
commit TRAN
--Theater data insert
Begin TRAN
insert into Theater(TheaterName,TheaterAddress,TheaterEmail,TheaterPhone)
select distinct
    [theater],
    [theater_address],
    [theater_email],
    [theater_phone]
from [RCTTC].[dbo].[rcttc-data];

Select * 
from Theater
commit TRAN
-- CustomerPerformance Insert
Begin TRAN

insert into CustomerPerformance(CustomerId, PerformanceId)
select distinct
    CustomerId,
    PerformanceId
from Ticket

SELECT * from CustomerPerformance;
commit TRANSACTION
 --PerfromanceTheater entry below
 Begin TRAN
 insert into PerformanceTheater(PerformanceId,TheaterId)
 select distinct
    p.PerformanceId,
   t.TheaterId
from [RCTTC].[dbo].[rcttc-data] r
inner join Performance p on p.Show = r.show
inner join Theater t on r.theater = t.TheaterName

Select*
from PerformanceTheater
commit tran

--Update Ticket Price
Begin TRANSACTION
update Ticket SET
TicketPrice = 22.25
 from Ticket t 
 Inner Join Performance p on p.StartDate = '2021-03-01' AND p.Show like 'The Sky Lit Up'
 where p.PerformanceId = t.PerformanceId
 
 select * from Ticket
COMMIT TRANSACTION
--Update Seating
Begin TRAN
update  Ticket SET
    Seat = 'B4'
    from Ticket t
    Inner Join Customer c on c.LastName = 'Bedburrow'
    where t.Seat = 'A4' and c.CustomerId = t.CustomerId

update  Ticket SET
    Seat = 'A4'
    from Ticket t
    Inner Join Customer c on c.LastName = 'Daouze'
    where t.Seat = 'A2' and c.CustomerId = t.CustomerId

update  Ticket SET
    Seat = 'A2'
    from Ticket t
    Inner Join Customer c on c.LastName = 'Vail'
    where t.Seat = 'C2' and c.CustomerId = t.CustomerId

update  Ticket SET
    Seat = 'C4'
    from Ticket t
    Inner Join Customer c on c.LastName = 'Guirau'
    where t.Seat = 'B4' and c.CustomerId = t.CustomerId



update  Ticket SET
    Seat = 'C2'
    from Ticket t
    Inner Join Customer c on c.LastName = 'Pettifor'
    where t.Seat = 'C4' and c.CustomerId = t.CustomerId

    SELECT * from Ticket where PerformanceId = 229

commit TRANSACTION
--Update Swindles PhoneNumber
Begin TRANSACTION
Update Customer SET
    CustomerPhone = '1-800-EAT-CAKE'
where CustomerPhone = '801-514-8648'

select * from Customer where LastName = 'Swindles'
commit tran

--Delete all single tickets in 10Pin

Begin TRAN
--Delete Brian Bake
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Brian' AND LastName = 'Bake' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Brian' AND LastName = 'Bake' AND PerformanceId = pt.PerformanceId)
--Delete Caye Treher
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Caye' AND LastName = 'Treher' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Caye' AND LastName = 'Treher' AND PerformanceId = pt.PerformanceId)
--Delete Emily Duffree
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Emily' AND LastName = 'Duffree' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Emily' AND LastName = 'Duffree' AND PerformanceId = pt.PerformanceId)
-- Flinn Crowcher
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Flinn' AND LastName = 'Crowcher' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Flinn' AND LastName = 'Crowcher' AND PerformanceId = pt.PerformanceId)
--Giraud Bachmann
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Giraud' AND LastName = 'Bachmann' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Giraud' AND LastName = 'Bachmann' AND PerformanceId = pt.PerformanceId)
--Hertha Glendining
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Hertha' AND LastName = 'Glendining' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Hertha' AND LastName = 'Glendining' AND PerformanceId = pt.PerformanceId)
--Loralie Rois
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Loralie' AND LastName = 'Rois' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Loralie' AND LastName = 'Rois' AND PerformanceId = pt.PerformanceId)
--Lucien Playdon
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Lucien' AND LastName = 'Playdon' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Lucien' AND LastName = 'Playdon' AND PerformanceId = pt.PerformanceId)
--Melamie Feighry
Delete from CustomerPerformance
where CustomerId like (Select Top 1 CustomerID from Customer
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Melamie' AND LastName = 'Feighry' AND PerformanceId = pt.PerformanceId);

Delete from Ticket
where CustomerId = (Select Top 1 CustomerID from Customer 
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
where FirstName = 'Melamie' AND LastName = 'Feighry' AND PerformanceId = pt.PerformanceId)

/*Delete from Ticket */
Select 
t.CustomerId,
c.FirstName,
c.LastName,
Count(t.CustomerId) numofPurchases
from Ticket t
Inner Join Theater th on th.TheaterName = '10 Pin'
Inner Join PerformanceTheater pt on pt.TheaterId = th.TheaterId
Inner Join Customer c on c.CustomerId = t.CustomerId
Where t.PerformanceId = pt.PerformanceId
Group by t.CustomerId, c.FirstName, c.LastName order by numofPurchases asc
/*
Group by t.TicketId, t.PerformanceId, t.Seat, t.CustomerId, t.TicketPrice, cup.CustomerId, cup.PerformanceId
Having Count(cup.CustomerId) = 1
Order by t.TicketId ASC
*/

commit TRAN
--Select * from Ticket where PerformanceId = 228
--Delete Liv Egle
Begin TRAN
Delete from CustomerPerformance
where CustomerId = (Select CustomerID from Customer where FirstName = 'Liv' AND LastName = 'Egle of Germany')
Delete from Ticket
where CustomerId = (Select CustomerID from Customer where FirstName = 'Liv' AND LastName = 'Egle of Germany')
Delete from Customer
where CustomerEmail = 'legleofgermanybh@blinklist.com'


COMMIT tran