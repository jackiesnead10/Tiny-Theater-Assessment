use RCTTC
--1.
Select * 
from Performance
where StartDate between '2021-10-1' and '2021-12-31'
--2. 
Select *
from Customer
--3.
Select *
from Customer
where CustomerEmail not like '%.com'
--4.
Select top(3)
min(TicketPrice) Price,
p.Show
from Ticket t
Inner join Performance p on t.PerformanceId = p.PerformanceId
group by p.Show order by Price
--5.
Select distinct
c.CustomerId,
cc.FirstName,
cc.LastName,
p.show
from CustomerPerformance c
inner join Performance p on c.PerformanceId = p.PerformanceId
inner join Customer cc on cc.CustomerId = c.CustomerId
--6
Select 
c.FirstName,
c.LastName,
p.Show,
th.TheaterName,
t.Seat
from Ticket t
inner join Customer c on c.CustomerId = t.CustomerId
inner join PerformanceTheater thp on thp.PerformanceId = t.PerformanceId
inner join Theater th on thp.TheaterId = th.TheaterId
inner join Performance p on p.PerformanceId = t.PerformanceId
--7
Select *
from Customer
where CustomerAddress is null;
--8
Select
c.FirstName,
c.LastName,
c.CustomerEmail,
c.CustomerPhone,
c.CustomerAddress,
t.Seat,
p.Show,
t.TicketPrice,
p.StartDate,
th.TheaterName,
th.TheaterAddress,
th.TheaterPhone,
th.TheaterEmail

from Ticket t
left outer join Customer c on c.CustomerId = t.CustomerId
inner join PerformanceTheater thp on thp.PerformanceId = t.PerformanceId
inner join Theater th on thp.TheaterId = th.TheaterId
inner join Performance p on p.PerformanceId = t.PerformanceId

--9
Select 
CustomerId,
Count(CustomerId) NumberOfTickets
from Ticket
Group by CustomerId Order by NumberOfTickets asc

--10
SELECT
p.Show,
Sum(TicketPrice) TotalRevenue
from Ticket t
Inner Join Performance p on p.PerformanceId = t.PerformanceId
Group by p.Show order by TotalRevenue asc

--11
SELECT
th.TheaterName,
Sum(TicketPrice) TotalRevenue
from Ticket t
Inner join PerformanceTheater pt on pt.PerformanceId = t.PerformanceId
Inner Join Theater th on th.TheaterId = pt.TheaterId
Group by th.TheaterName order by TotalRevenue asc


--12
SELECT top 1
c.FirstName,
c.LastName,
Sum(TicketPrice) TotalRevenue
from Ticket t
Inner Join Customer c on c.CustomerId = t.CustomerId
Group by c.FirstName, c.LastName order by TotalRevenue desc




